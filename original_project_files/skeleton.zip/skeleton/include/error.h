#ifndef ERROR_H
#define ERROR_H

extern const int vdisk_ENODISK ;
extern const int vdisk_EACCESS ;
extern const int vdisk_ENOEXIST;
extern const int vdisk_EEXCEED ;
extern const int vdisk_ESECTOR ;

#endif
